# Oricode AI - ABAP Coding Assistant

[![Eclipse Marketplace](https://img.shields.io/badge/Eclipse%20Marketplace-Oricode%20AI-orange)](https://marketplace.eclipse.org/content/oricode-ai)
[![GitHub release](https://img.shields.io/github/v/release/Teddy-Layani/oricode-ai-eclipse)](https://github.com/Teddy-Layani/oricode-ai-eclipse/releases)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

**AI-powered coding assistant for SAP ABAP developers with direct SAP system integration.**

![Oricode AI Screenshot](docs/screenshot.png)

---

## 🚀 Quick Start

### 1. Install Plugin

**From Eclipse Marketplace (Recommended):**
```
Help → Eclipse Marketplace → Search "Oricode AI" → Install
```

**Or Manual Installation:**
1. Download `com.oricode.ai_1.0.0.jar` from [Releases](https://github.com/Teddy-Layani/oricode-ai-eclipse/releases)
2. Copy to your Eclipse `dropins` folder
3. Restart Eclipse

### 2. Get Your FREE API Key

👉 **https://app.oricode.ai** 

Sign up and get your API key in 30 seconds. Free tier includes 50,000 tokens/month.

### 3. Configure Plugin

1. In Eclipse: `Window → Preferences → Oricode AI`
2. Enter your API key
3. Configure your SAP connection (optional - for MCP features)
4. Click Apply

### 4. Start Coding with AI!

```
Window → Show View → Other → Oricode AI
```

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🤖 **AI Chat** | Natural language conversations about your ABAP code |
| 🔍 **Read SAP Objects** | Browse classes, programs, function modules, tables directly from chat |
| ✏️ **Create Code** | Generate new ABAP classes and programs with AI |
| 🔄 **Modify Code** | Update existing code with intelligent suggestions |
| 📚 **Template Library** | Save and reuse code patterns |
| 💬 **Chat History** | Resume conversations where you left off |
| 🔐 **Secure** | Your code stays private, API key encrypted |

---

## 📦 Downloads

### Eclipse Plugin

| File | Description |
|------|-------------|
| [com.oricode.ai_1.0.0.jar](https://github.com/Teddy-Layani/oricode-ai-eclipse/releases/latest/download/com.oricode.ai_1.0.0.jar) | Eclipse plugin (copy to dropins) |

### MCP Server (Optional - for SAP integration)

| Platform | Download |
|----------|----------|
| Windows | [oricode-mcp-server.exe](https://github.com/Teddy-Layani/oricode-ai-eclipse/releases/latest/download/oricode-mcp-server.exe) |
| macOS | [oricode-mcp-server-macos](https://github.com/Teddy-Layani/oricode-ai-eclipse/releases/latest/download/oricode-mcp-server-macos) |
| Linux | [oricode-mcp-server-linux](https://github.com/Teddy-Layani/oricode-ai-eclipse/releases/latest/download/oricode-mcp-server-linux) |

### Complete Bundle

| Platform | Download |
|----------|----------|
| All-in-One | [oricode-bundle-1.0.0.zip](https://github.com/Teddy-Layani/oricode-ai-eclipse/releases/latest/download/oricode-bundle-1.0.0.zip) |

---

## 🔑 API Key

Get your **FREE** API key at **https://app.oricode.ai**

### Pricing

| Plan | Tokens/Month | Price |
|------|--------------|-------|
| **Free** | 50,000 | $0 |
| **Pro** | 500,000 | $19/mo |
| **Team** | 2,000,000 | $49/mo |

No credit card required for free tier.

---

## 🛠️ Requirements

- **Eclipse:** 2023-03 or later
- **ADT:** ABAP Development Tools installed
- **Java:** 11 or higher
- **SAP System:** Access to SAP system (for MCP features)

---

## 📖 Documentation

- [Installation Guide](INSTALL.md)
- [User Guide](https://docs.oricode.ai)
- [MCP Server Setup](docs/MCP_SETUP.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [API Reference](https://docs.oricode.ai/api)

---

## 🎬 Demo

```
You: Create a class ZCL_SALES_ORDER with a method GET_ORDERS that selects from VBAK

Oricode AI: I'll create that class for you in $TMP package...
✅ Class ZCL_SALES_ORDER created
✅ Source code added
✅ Class activated

The class is ready to use!
```

---

## 🤝 Support

- 🐛 **Issues:** [GitHub Issues](https://github.com/Teddy-Layani/oricode-ai-eclipse/issues)
- 💬 **Discussions:** [GitHub Discussions](https://github.com/Teddy-Layani/oricode-ai-eclipse/discussions)
- 📧 **Email:** support@oricode.ai
- 🌐 **Website:** https://oricode.ai

---

## 🗺️ Roadmap

- [x] AI Chat with ABAP context
- [x] Read SAP objects (classes, programs, tables)
- [x] Create/Modify ABAP code
- [x] Template library
- [x] Chat history sync
- [ ] VS Code extension
- [ ] Code review assistant
- [ ] Unit test generation
- [ ] Transport management

---

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgments

- Built with [Claude AI](https://anthropic.com) by Anthropic
- SAP ADT integration via [abap-adt-api](https://github.com/nicepkg/abap-adt-api)
- MCP protocol by [Model Context Protocol](https://modelcontextprotocol.io)

---

**Made with ❤️ for ABAP developers**

⭐ Star this repo if you find it useful!
#   o r i c o d e - a i - e c l i p s e  
 